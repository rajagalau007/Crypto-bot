#!/usr/bin/env python3
"""
UNIFIED BOT - NFT Monitor + Degen Coin Hunter
Monitor NFT free mints + New degen coins + Pump detection
With stop loss / take profit alerts
"""

import os
import sys
import time
import threading
from datetime import datetime
from dotenv import load_dotenv

# Import modules
try:
    from nft_monitor_enhanced import EnhancedNFTMonitor
    from degen_hunter import DegenCoinHunter
except ImportError:
    print("❌ Error: Cannot import modules")
    print("Make sure nft_monitor_enhanced.py and degen_hunter.py exist")
    sys.exit(1)

class UnifiedBot:
    def __init__(self):
        load_dotenv()
        
        self.telegram_token = os.getenv('TELEGRAM_BOT_TOKEN', '')
        self.telegram_chat_id = os.getenv('TELEGRAM_CHAT_ID', '')
        
        if not self.telegram_token or not self.telegram_chat_id:
            print("❌ Missing Telegram configuration!")
            sys.exit(1)
        
        # Initialize monitors
        self.nft_monitor = EnhancedNFTMonitor(self.telegram_token, self.telegram_chat_id)
        self.degen_hunter = DegenCoinHunter(self.telegram_token, self.telegram_chat_id)
        
        # Settings
        self.nft_interval = int(os.getenv('NFT_CHECK_INTERVAL', '5'))
        self.degen_interval = int(os.getenv('DEGEN_CHECK_INTERVAL', '3'))
        self.enable_nft = os.getenv('ENABLE_NFT', 'true').lower() == 'true'
        self.enable_degen = os.getenv('ENABLE_DEGEN', 'true').lower() == 'true'
        
    def run_nft_monitor(self):
        """Run NFT monitoring in thread"""
        print(f"🎨 NFT Monitor thread started (interval: {self.nft_interval}m)")
        while True:
            try:
                self.nft_monitor.run_monitoring_cycle()
                time.sleep(self.nft_interval * 60)
            except Exception as e:
                print(f"NFT Monitor error: {e}")
                time.sleep(60)
    
    def run_degen_hunter(self):
        """Run degen coin hunter in thread"""
        print(f"💎 Degen Hunter thread started (interval: {self.degen_interval}m)")
        while True:
            try:
                self.degen_hunter.run_monitoring_cycle()
                time.sleep(self.degen_interval * 60)
            except Exception as e:
                print(f"Degen Hunter error: {e}")
                time.sleep(60)
    
    def run(self):
        """Run unified bot with both monitors"""
        print("""
╔═══════════════════════════════════════════════════════════════════╗
║                                                                   ║
║     UNIFIED BOT - NFT MONITOR + DEGEN COIN HUNTER                ║
║              All-in-One Crypto Opportunity Scanner                ║
║                                                                   ║
╚═══════════════════════════════════════════════════════════════════╝
""")
        
        print("Configuration:")
        print(f"  🎨 NFT Monitor: {'✅ ENABLED' if self.enable_nft else '❌ DISABLED'} (interval: {self.nft_interval}m)")
        print(f"  💎 Degen Hunter: {'✅ ENABLED' if self.enable_degen else '❌ DISABLED'} (interval: {self.degen_interval}m)")
        print()
        
        # Send startup message
        startup_msg = """
🤖 <b>UNIFIED BOT STARTED!</b>

<b>Active Modules:</b>
"""
        if self.enable_nft:
            startup_msg += f"✅ NFT Monitor ({self.nft_interval}m interval)\n"
            startup_msg += "   → 7+ platforms, pump analysis\n"
        
        if self.enable_degen:
            startup_msg += f"✅ Degen Hunter ({self.degen_interval}m interval)\n"
            startup_msg += "   → New launches, pumps, price alerts\n"
        
        startup_msg += "\n<b>Stay safe & DYOR!</b> 🚀"
        
        self.nft_monitor.send_telegram_alert(startup_msg)
        
        # Start threads
        threads = []
        
        if self.enable_nft:
            nft_thread = threading.Thread(target=self.run_nft_monitor, daemon=True)
            nft_thread.start()
            threads.append(nft_thread)
        
        if self.enable_degen:
            degen_thread = threading.Thread(target=self.run_degen_hunter, daemon=True)
            degen_thread.start()
            threads.append(degen_thread)
        
        if not threads:
            print("❌ No modules enabled! Enable NFT or DEGEN in .env")
            sys.exit(1)
        
        # Keep main thread alive
        try:
            print("\n✅ Bot running... Press Ctrl+C to stop\n")
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\n🛑 Stopping bot...")
            self.nft_monitor.send_telegram_alert("🛑 <b>Unified Bot Stopped</b>")
            sys.exit(0)


def main():
    """Main entry point"""
    bot = UnifiedBot()
    bot.run()


if __name__ == "__main__":
    main()
